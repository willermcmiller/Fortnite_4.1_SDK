#pragma once

// Fortnite SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Announce_NoDurability.Announce_NoDurability_C.UserConstructionScript
struct AAnnounce_NoDurability_C_UserConstructionScript_Params
{
};

// Function Announce_NoDurability.Announce_NoDurability_C.OnClientAnnouncementStart
struct AAnnounce_NoDurability_C_OnClientAnnouncementStart_Params
{
};

// Function Announce_NoDurability.Announce_NoDurability_C.ExecuteUbergraph_Announce_NoDurability
struct AAnnounce_NoDurability_C_ExecuteUbergraph_Announce_NoDurability_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
