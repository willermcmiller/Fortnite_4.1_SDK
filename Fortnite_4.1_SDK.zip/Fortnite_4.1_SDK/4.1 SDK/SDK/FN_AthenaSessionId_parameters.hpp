#pragma once

// Fortnite SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AthenaSessionId.AthenaSessionId_C.UpdateSessionId
struct UAthenaSessionId_C_UpdateSessionId_Params
{
};

// Function AthenaSessionId.AthenaSessionId_C.Construct
struct UAthenaSessionId_C_Construct_Params
{
};

// Function AthenaSessionId.AthenaSessionId_C.ExecuteUbergraph_AthenaSessionId
struct UAthenaSessionId_C_ExecuteUbergraph_AthenaSessionId_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
