#pragma once

// Fortnite SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function B_CameraRainDrops_01.B_CameraRainDrops_01_C.UserConstructionScript
struct AB_CameraRainDrops_01_C_UserConstructionScript_Params
{
};

// Function B_CameraRainDrops_01.B_CameraRainDrops_01_C.ReceiveBeginPlay
struct AB_CameraRainDrops_01_C_ReceiveBeginPlay_Params
{
};

// Function B_CameraRainDrops_01.B_CameraRainDrops_01_C.ExecuteUbergraph_B_CameraRainDrops_01
struct AB_CameraRainDrops_01_C_ExecuteUbergraph_B_CameraRainDrops_01_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
